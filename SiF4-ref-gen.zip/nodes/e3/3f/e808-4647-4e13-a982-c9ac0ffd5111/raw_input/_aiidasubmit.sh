#!/bin/bash -l
#SBATCH --no-requeue
#SBATCH --job-name="aiida-14470"
#SBATCH --get-user-env
#SBATCH --output=_scheduler-stdout.txt
#SBATCH --error=_scheduler-stderr.txt
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=36
#SBATCH --time=01:00:00


### computer prepend_text start ###
#SBATCH --partition=normal
#SBATCH --account=mr0
#SBATCH --constraint=mc
#SBATCH --cpus-per-task=1
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
source $MODULESHOME/init/bash
module load daint-mc
ulimit -s unlimited
### computer prepend_text end ###


module load QuantumESPRESSO/6.6-CrayIntel-20.08 


'srun' '/apps/daint/UES/jenkins/7.0.UP02/mc/easybuild/software/QuantumESPRESSO/6.6-CrayIntel-20.08/bin/pw.x' '-ndiag' '1' '-in' 'aiida.in'  > 'aiida.out' 
